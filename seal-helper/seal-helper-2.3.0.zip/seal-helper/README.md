# Seal Helper

A Chrome extension that makes Seal calmer, easier to read and easier to write in. Navigation and reading only change how Seal looks in your own browser. Since 2.0 it also helps you write: it writes to a record only where your cursor is, when you ask (a button, a shortcut, Ctrl V), through Seal's own editor, so Seal records it as your edit and Ctrl Z undoes it. It sends nothing anywhere.

## Install (2 minutes)

1. Download `seal-helper-2.3.0.zip` and unzip it.
2. Open `chrome://extensions` and switch on **Developer mode** (top right).
3. Click **Load unpacked** and pick the unzipped `seal-helper` folder.
4. Open Seal. Click the extension icon (puzzle piece, then pin Seal Helper) to switch each setting on or off.

To update: replace the folder with the new one, then click the reload arrow on the Seal Helper card in `chrome://extensions`.

## If you see no change

Click the extension icon on a Seal tab: the first card says whether Seal Helper is **active on this tab**, **paused**, or whether the tab **needs a reload** after an update (one button does it). After replacing the folder, always press the reload arrow on the Seal Helper card in `chrome://extensions`, then reload Seal. The sidebar shows its version (v2.3.0) at the bottom.

## 2.3

- **Bench sheet on paper or as a PDF**: in Bench mode, **Print / PDF** (or Ctrl P) prints the checklist alone: the record title, a line for the date and the name, each step with its box, a blank line for the time, the values in bold, and the ticks and deviations already noted. Choose *Save as PDF* in the print window to get a file.
- **Ctrl S publishes**: on a record or a change where Seal shows a Publish button (Publish, Review and publish, Submit for review), Ctrl S (⌘S on a Mac) presses it for you. It never presses Approve, and whatever Seal asks next, a comment or a confirmation, is still yours to answer. Switch it off under Writing, *Ctrl S publishes*.

## 2.2

- **Find and replace** in the open record: the **Find** button of the bar, or Ctrl H (⌘⇧H on a Mac). Every match is highlighted and counted, Enter goes to the next one, **Replace** and **Replace all** type the new text for you (Ctrl Z undoes each one). Words split by a change of formatting in the middle are not matched.
- **Check** in the bar, before you publish: sections with nothing under their heading, template hints left in place, TODO / TBC / ???, deviations without text, tables that are mostly empty, bench ticks not yet written as a run log, a record still called Untitled. Click a line to go there. It only reads; Seal's review stays Seal's.

## 2.1

- **The converter inside Seal**: copy a whole protocol in Word (or a web page, Google Docs), press Ctrl V in a Seal record, and it arrives in the lab protocol format of seal-converter, written by the same engine: chapters I, II, sections a, b, steps renumbered, values in blue, the title block left to Seal. It applies when the paste has headings or at least three steps; a shorter paste keeps its own layout. The message offers **Keep the Word layout** (same content, original structure), **Paste as it was** and **Undo**. Switch it off under Writing, *Lab protocol format*. The converter page remains the place to open .docx and .pdf files, migrate many documents and check that nothing was lost.

## 2.0.1

- **After a fresh install**, the sidebar has not read the lab notebook yet and only showed Seal view shortcuts. It now starts with **Open the lab notebook**: one click opens the notebook page (Start Here), and its sections (Projects, Experiments, Protocols…) then show in the sidebar for good.

## 2.0: writing

A bar sits at the bottom of every record. While you read it offers **Bench** and **Aa**; once your cursor is in the text it adds the writing tools. Each one can be switched off in the extension menu, under Writing.

- **Value, Clear, B, I**: select words, then press **Value** to put them in Seal's blue bold (press again inside a value to remove it), or **Clear** to drop the formatting. A small bubble with the same buttons follows the selection.
- **Clean paste**: Ctrl V from Word, Excel, Google Docs or a web page keeps headings, steps with their sub-steps, bullets, tables, bold, italic and links, and marks volumes, times and temperatures in blue. A message says what was kept and offers **Undo** and **Paste as it was**. Ctrl Shift V always pastes Seal's own way.
- **Blocks** (the button, Ctrl J, or type `/` at the start of a word): **Antibody mix** calculated from a panel pasted from Excel (samples, excess, µL per test, the buffer to top up with, Brilliant Stain Buffer as an option), **Table**, **Buffer recipe**, **Deviation** with date and time, **Date**, **Time**, section outlines for **Flow staining**, **ELISA**, **qPCR** and **Mouse cohort**, and **My snippets**: select a passage, Blocks, *Save the selection as a snippet*, and it is one word away next time. Snippets stay in this browser.
- **µ °C ±**: lab symbols in one click.
- **Bench mode**: the steps of the record as a checklist you can read from a metre away. Tick a step (the time is noted), start a timer from a duration written in the step, note a deviation on the step where it happened. Ticks stay in this browser; **Add run log to the record** writes a dated table (step, done at, deviation) where your cursor is.
- **Aa, reading comfort**: text size, page width, typeface (Seal, Atkinson Hyperlegible, serif), a focus mode without the sidebar and panels, table headers kept in view. Only you see these settings; nothing is written to the record, and colleagues see Seal as usual.

What it does not do: headings and list types are left to Seal's own buttons; a typeface or text colour that everyone would see is not possible, because Seal does not store one.

If something is refused, a message says "Seal did not accept this here" and nothing is changed. The **Diagnostic** button of the extension menu now ends with a few lines about the editor (structure only, no record content): paste them to report a problem.

## 1.9

- **Seal menus stay on top**: right-click menus, dropdowns, dialogs and tooltips of Seal now show above the sidebar instead of being cut off on the left.
- **Deleted records leave the lists**: a record you delete (or that turns out not to exist any more) is removed at once from My work, the instant lists, Today and Find.
- **Snappier**: the sidebar and the record bar follow Seal faster, and the cover screen lifts sooner.

## 1.8

- **Find in the notebook**: the search box at the top of the sidebar filters your notebook lists as you type (name, ID or project); arrows and Enter open, Ctrl+click opens in a new tab, and “Search all of Seal” (Ctrl K) is still one step away. Press / to jump to it.
- **Back to the list**: a record opened from a list or from My work shows a “‹ Experiments” button that brings the list back at once, with its filter.

## 1.7

- **Instant lists from a record**: Experiments, Projects and Protocols open at once in the sidebar's own page, from the table last seen in the notebook (filter, status, Ctrl+click for a new tab). **Open in the notebook** shows the live section.

## 1.6

- **Back to a list without reloading**: Ctrl+click (⌘+click on a Mac) or middle click on a record in Today, My work or the notebook lists opens it in a new tab; the list stays open in the first tab.
- **Cover screen**: going between a record and the notebook shows a calm screen named after the destination until the right view is ready.

## 1.5.6

- **Quiet on the notebook page**: while the notebook page is shown, the extension only reads; it no longer opens Seal’s Views and Changes tabs in the background, unfolds view groups, closes the Info panel or touches the browser history there. The changes list fills once you open a record or a Seal view, and then stays.

## 1.5.5

- **One menu for the lab notebook is now off by default** (and switched off once for everyone): the notebook page published as v10 does not start when its menu is hidden or its frame is resized. The notebook keeps its own menu next to the sidebar until the notebook supports it.

## 1.5.4 fixes

- When the notebook reloads its frame after a click (v10 does), the click is never repeated. The Diagnostic counts the frame loads.

## 1.5.3 fixes

- The notebook menu is no longer hidden by changing anything in the notebook: its frame is shifted left, in the Seal page, by the width of the menu, which thus sits off screen. The notebook keeps its menu intact and measurable (v10 reloaded whenever its menu lost its size).

## 1.5.2 fixes

- The notebook page (v10) reloaded endlessly when its menu was hidden: hiding it wrote a style element and an attribute into the notebook document. Nothing is written there any more: the menu is hidden through an adopted stylesheet and structural selectors only.

## 1.5.1 fixes

- Flicker: the sidebar is now built before the old one is replaced, so an error can no longer leave the page without it; a render loop is detected and paused; the notebook tables are read at most every 5 seconds and never throw. The Diagnostic now shows the last error.

## What 1.5 adds

- **My work shows the whole notebook**: once you have opened the Experiments (or Projects) section of the notebook, its full table is kept in this browser and My work lists every experiment with project and status, filterable. Until then it shows the recent ones and says so.

## 1.4.2 fixes

- A record that embeds its own frame (for example the list of protocol templates inside an experiment) was taken for the notebook page: the sidebar sections did nothing from there, and the record bar was missing. Only a frame that carries the lab menu counts as the notebook now.

## 1.4.1 fixes

- From a record, clicking a notebook section brought the notebook home page but not the section: the notebook shows its menu before it listens to clicks. The click is now repeated until the section is active (at most five times).

## What 1.4 adds

- **Keyboard shortcuts** (outside a text field): N new record, T Today, W My work, P To publish, G then the first letter of a notebook section, / search, ? shows the list. Also in the ? menu.
- **Dark mode**: when Seal is dark, the sidebar and pages follow.

## What 1.3 adds

- **Print** in the record bar: the record prints as a clean notebook page, without the Seal panels, drawers and bars (with the Clean documents setting).
- **Records open by their address**: a notebook record whose identifier is a Seal identifier opens directly, without going through the notebook home page first.

## What 1.2 adds

- **Record actions in the bar**: on the right of the bar under the title, the status (click to change it), the version, Edit, the changes of this version, the change set, and the publish or review button when Seal offers one. Each one presses the matching Seal button.

## What 1.1 adds

- **Project in the record breadcrumb**: on an experiment, the bar under the title reads Notebook › Experiments › *Project* › ID; the project opens in one click.
- **Reset menu hiding** in the popup: if an empty column stays on the left of the notebook (a setting learned by an earlier version), press it once and reload Seal.

## 1.0.3 fixes

- The visibility check no longer counts what is below the fold as hidden (the notebook page scrolls): a long table no longer makes the extension change how it hides the menu.

## 1.0.2 fixes

- The way the notebook menu is hidden is learned once and remembered in this browser, never measured while a page is changing, and the menu is never shown again by itself.
- To publish and Today say "Loading your changes from Seal…" until Seal has filled its list, instead of "Nothing waiting".

## 1.0.1 fixes

- A notebook section that showed nothing (Experiments) while the menu was hidden: the extension now checks, after hiding the menu, that the notebook content fills the frame; if not it hides the menu more gently, and as a last resort keeps the menu and says so.
- The popup has a **Diagnostic** button: it copies the structure of the page (no record content) to paste when something looks wrong.

## What 1.0 changes: the sidebar, reorganised

- **Lab notebook first**: Overview, Projects, Experiments, Protocols, Inventory, Calculators & files, with their counts.
- **You**: Today, My work, To publish. Inbox lives on the To publish page (a tab opens your Seal inbox) and as an icon at the bottom.
- **Recent**: the five records you opened last, a coloured dot for their status.
- **Favourites**, then **Seal views**, folded by default with their count.
- **Help moved to the « ? » at the bottom**: How to, Lab tree, Seal FAQs, Give feedback, Seal's own help, and the Getting around card.

## 0.9.2 fixes

- No more flash of the notebook's home page or of its own menu when you open a section or create something: the work area is covered until the notebook shows the result (at most a few seconds), and the hidden menu is hidden by its own structure, even when the notebook redraws it.
- When a New button is not on the notebook view you are in, the notebook's first section is opened first, then the button pressed.

## 0.9.1 fixes

- Clipped text in the sidebar and on Today (descenders cut, lines overlapping): the extension's text no longer inherits Seal's line height.
- Blank notebook section: the hidden menu column kept its height in the notebook's grid and pushed the content below the screen; it is now taken out of the layout entirely.

## What 0.9 adds

- **My work from the notebook**: the experiments and projects of the lab notebook, with their status (Planned, In progress, Active…), filtered by status or by name, each opening in the notebook. A switch shows your recent Seal records instead.
- **Getting around**: a short card on Today with the four moves (New, Ctrl K, arrows, Classic Seal); Got it hides it for good.
- **Last used first**: the New menu puts what you created last at the top of its group, with a small Last used tag.

## 0.8.1 fixes

- The notebook page was squeezed into the width of its hidden menu: the menu column is now collapsed to zero width and the page takes the whole space.
- The sidebar could follow a sideways scroll of the page: it is now anchored to the window and the page no longer scrolls sideways.
- Seal's « Start Here » record (the page that holds the notebook) is recognised as the notebook: the sidebar says *Notebook / Overview*, the sections highlight, no record header is added there.
- **Open on Today** now does what it says on any lab: Today first when you arrive, one click to the notebook. Switch it off in the popup to land on the notebook page.
- Views kept in folded groups are found (the groups are unfolded once in the hidden Seal panel), so *from template* finds Protocols or Projects wherever they are; without such a view it falls back to Seal's own **+ New** list.
- Experiments in progress and projects counted next to their section in the sidebar.

## What 0.8 adds

- **New from a template**: the New menu has two groups. *In the lab notebook* presses the notebook's own buttons (New experiment, New project, New protocol, New antibody panel), each with a one-line hint. *From a Seal template* opens the matching Seal view (Protocols, Projects, Experiments when such a view exists) and its **+ New instance** list, where every template of that type is offered; nothing is created until you pick one.
- **You always see what is happening**: a short message at the bottom says what is being opened ("Opening New experiment…", "Choose a template in the list") and, if a button cannot be found, what to do instead. If reaching the notebook needs a page reload, the action you asked for is replayed after it.
- **Never a blank sidebar**: each part of the page is read on its own, so one unexpected page can no longer stop the sidebar from showing. The extension popup tells you whether it is running on the current tab.
- **Where you are**: inside a Seal view, the sidebar says *View / Protocols*.

## What 0.7 does

**Layout**
- **Built for the lab notebook app**: its menu (Overview, Projects, Experiments, Protocols, Inventory, Calculators & files, How to, Lab tree, Seal FAQs, Give feedback) is read exactly and shown in the sidebar; its own menu is hidden so there is one. A **New** button at the top of the sidebar lists what the notebook can create (New experiment, New project, New protocol, New antibody panel…) and presses the notebook's own button, so templates and IDs stay the notebook's job. Each section in the sidebar has a + on hover.
- **Today shows the notebook's real numbers**: experiments in progress, projects (with how many are active), protocol templates, plus what is waiting to be published; the experiment to continue with its real status, recent experiments with Planned / In progress pills, projects as cards with their experiment counts, protocol templates. All of it opens in the notebook.
- **Finds a lab notebook menu from what it shows**, whatever it is built with, and loads Seal's Views and Changes lists by itself (Seal only fills them once their tab is opened), so shortcuts and counts no longer disappear after a reload.
- **Today, a real dashboard**: greeting and date, a big search, four counters (in progress, to publish, published, last 7 days), the record to pick up with the next ones, the lab notebook sections as tiles, a to-publish checklist, the last 7 days as a strip with an activity log, favourites.
- **Know where you are**: back and forward arrows at the top of the sidebar (Alt ← and Alt → too), Today, My work and To publish are part of the browser history, the sidebar says where you are, and a record shows Notebook › Experiments › its ID.
- **Lab notebook in the sidebar**: if your lab's home page in Seal is a notebook app with its own menu (Overview, Projects, Experiments, Protocols, Inventory...), that menu moves into the sidebar. A click opens the section, from anywhere in Seal. On a record, the section it belongs to is highlighted and a « ‹ Experiments » button takes you back to it. The app's own menu is hidden to keep one menu (option in the extension menu); it comes back as soon as Seal Helper is off.
- **New sidebar**: Today, My work, To publish, Inbox, then the lab sections (or, for a lab without a notebook page, **Lab** shortcuts to Seal views) and favourites. Each shortcut opens one of your Seal views: found by its name, or chosen once with the pencil next to it (remembered in this browser). Add your own with Add a shortcut. All views are still there, folded, under All views. Inside a change, the records of that change are listed at the top, same names grouped (×8). Search with Ctrl K (⌘K on a Mac). "Classic Seal" at the bottom brings the usual Seal bar back.
- **Today**: where you left off, what is waiting to be published, what you created, your favourites. The lab guide is one click away.
- **My work** and **To publish**: full pages, filter by name or by type (Experiments, Documents, Projects), changes grouped by day, empty changes hidden.
- **Record header and outline**: the key fields of a record (ID, owner, dates, status) under its title bar, and its headings on the right when the screen is wide enough.

Every line clicks the matching Seal line for you, so opening, rights and publishing stay Seal's own. The extension never publishes, signs or changes a status by itself: Ctrl S only presses Seal's Publish button when you press the keys.

**Clean up**
- **Clean documents**: change bars show on hover only, lines of dashes become a thin rule, the first table row reads as a header.
- **Short dates and titles**: no time zone written out on every date (the full date stays in the tooltip); change titles without the repeated number.
- **Info panel closed**: closed when you open a record; open it again whenever you need it.
- **Quieter lists**: empty changes and Untitled or test drafts are dimmed, never hidden.

It runs only on `https://us.platform.seal.run/o/malaghan/*`. If Seal changes a page and a landmark disappears, that setting simply does nothing.
